// Executes only the actual, pinned production export functions.
import { createRequire } from 'node:module';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { join, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';
const R = '/Users/saleh/Developer/career-finder-feed-continuation-20261117-4b851318da2d';
const D = dirname(fileURLToPath(import.meta.url));
const require = createRequire(pathToFileURL(join(R, 'hosted/package.json')));
const { build } = require('esbuild');
const manifest = JSON.parse(await readFile(join(D, 'source-manifest.json'), 'utf8'));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
for (const source of manifest.source) assert.equal(hash(await readFile(join(R, source.path))), source.sha256);
const entries = [['app/phone/record-tools.ts','tools'],['app/phone/model.ts','model'],['app/i18n/core.ts','i18n']];
for (const [entry, name] of entries) await build({ absWorkingDir: join(R, 'hosted'), entryPoints: [entry], outfile: join(D,'bundled',name+'.mjs'), bundle:true, platform:'node', format:'esm', logLevel:'silent' });
const tools = await import(pathToFileURL(join(D,'bundled/tools.mjs')).href);
const model = await import(pathToFileURL(join(D,'bundled/model.mjs')).href);
const i18n = await import(pathToFileURL(join(D,'bundled/i18n.mjs')).href);
const scenarios = [
 { name:'mixed', title:'مُهندس, "أول" 🧭 — R&D', company:'شركة الاختبار\nTest Corp', note:'First line\r\nنص عربي, "quoted"\nThird line\tend' },
 { name:'leading-zero', title:'000123', company:'01234567890123456789', note:'00123' },
 { name:'number-like', title:'1E03', company:'2.50', note:'03/04/2026' },
 { name:'date-like-text', title:'2026-11-17', company:'2026/11/18', note:'01234567890123456789' },
 { name:'formula-equals', title:'=1+1', company:'=1+1', note:'=1+1' },
 { name:'formula-space', title:'  =1+1', company:'  =1+1', note:'  =1+1' },
 { name:'formula-tab', title:'\t=1+1', company:'\t=1+1', note:'\t=1+1' },
 { name:'formula-directional', title:'\u2066=1+1', company:'\u2066=1+1', note:'\u2066=1+1' },
 { name:'formula-fullwidth', title:'＝1+1', company:'＝1+1', note:'＝1+1' },
 { name:'formula-quote', title:"'=1+1", company:"'=1+1", note:"'=1+1" },
 { name:'formula-plus', title:'+1+1', company:'+1+1', note:'+1+1' },
 { name:'formula-negative', title:'-1+1', company:'-1+1', note:'-1+1' },
 { name:'formula-at', title:'@SUM(A1:A2)', company:'@SUM(A1:A2)', note:'@SUM(A1:A2)' },
 { name:'existing-marker', title:'Text: =already', company:'Text: =already', note:'Text: =already' },
 { name:'empty', title:'', company:'', note:'', appliedDate:'', followUpDate:'' },
 { name:'limits', title:'أ'.repeat(498)+'🧭', company:'ب'.repeat(250), note:'ن'.repeat(4998)+'🧭' },
 { name:'unicode-original', title:'e\u0301cole / École', company:'أإآاةهىـ\u064e', note:'preserve\t  spaces  \nالرياض' },
];
const records = scenarios.map((value,index) => {
 const job = { id:'synthetic-consumer-'+index, title:value.title, company:value.company, location:'الرياض / Riyadh',country:'SA',url:'https://example.org/career-finder-consumer/'+index };
 const record = { ...model.blankRecord(job), note:value.note, stage:index%2 ? 'interview':'saved', appliedElsewhere:index%2===1, appliedDate:index%2?'2026-11-17':'', followUpDate:'2026-11-24', updatedAt:'2026-11-17T23:30:00+03:00', ...value };
 delete record.name;
 model.recordSchema.parse(record);
 return Object.freeze(record);
});
const original = JSON.stringify(records);
await writeFile(join(D,'generated/original-records.json'), JSON.stringify({scenarios:scenarios.map(s=>s.name),records},null,2)+'\n');
const generated = [];
async function save(name,value,meta={}) { const p=join(D,'generated',name); await mkdir(dirname(p),{recursive:true}); await writeFile(p,value); generated.push({name,bytes:Buffer.byteLength(value),sha256:hash(value),...meta}); }
for (const language of ['en','ar']) {
 const copy = key => i18n.translate(key,language);
 const inputs=records.map(r=>({...r,email:'SYNTHETIC_EXCLUDED_EMAIL',accessToken:'SYNTHETIC_EXCLUDED_TOKEN',resume:{dataBase64:'SYNTHETIC_EXCLUDED_CV'},password:'SYNTHETIC_EXCLUDED_PASSWORD'}));
 const csv=tools.applicationRecordsCSV(inputs,copy);
 for(const secret of ['SYNTHETIC_EXCLUDED_EMAIL','SYNTHETIC_EXCLUDED_TOKEN','SYNTHETIC_EXCLUDED_CV','SYNTHETIC_EXCLUDED_PASSWORD'])assert(!csv.includes(secret));
 await save('career-records-'+language+'.csv',csv,{language,records:records.length,format:'production CSV'});
}
const main = {...records[0],note:'SYNTHETIC_NOTE_NOT_FOR_CALENDAR',title:'متابعة 🧭 Frontend, "أول"; \\ path\r\nBEGIN:VEVENT',company:'شركة الاختبار / Test Corp'};
const calendarCases = [
 {name:'follow-up-en',language:'en',record:main},
 {name:'follow-up-ar',language:'ar',record:main},
 {name:'same-day-updated-caption-en',language:'en',record:{...main,title:'Updated title',note:'OTHER_PRIVATE_NOTE'}},
 {name:'changed-day-en',language:'en',record:{...main,followUpDate:'2026-11-25'}},
];
for (const c of calendarCases) {
 const value=await tools.followUpCalendar(c.record,key=>i18n.translate(key,c.language));
 assert(!value.includes(c.record.note));
 await save(c.name+'.ics',value,{language:c.language,civilDate:c.record.followUpDate,identity:c.record.identity,format:'production ICS',purpose:c.name});
}
await writeFile(join(D,'generated/calendar-reference.json'),JSON.stringify(calendarCases,null,2)+'\n');
const zones=['Asia/Riyadh','Pacific/Kiritimati','Pacific/Pago_Pago','UTC'];
const civilDates=['2026-03-08','2026-11-01','2000-02-29','9999-12-31'];
const originalTZ=process.env.TZ;
for(const zone of zones) {
 process.env.TZ=zone;
 for(const day of civilDates) {
  const value=await tools.followUpCalendar({...main,followUpDate:day});
  await save('calendar-boundaries/'+zone.replaceAll('/','_')+'-'+day+'.ics',value,{zone,civilDate:day,format:'production ICS boundary'});
 }
}
if(originalTZ===undefined) delete process.env.TZ; else process.env.TZ=originalTZ;
await assert.rejects(tools.followUpCalendar({...main,followUpDate:''}),/valid follow-up date/);
assert.throws(()=>tools.applicationRecordsCSV([{...main,title:'bad\u0000value'}]));
assert.equal(JSON.stringify(records),original);
for (const source of manifest.source) assert.equal(hash(await readFile(join(R, source.path))), source.sha256);
await save('positive-control.csv','"Control"\r\n"=1+1"\r\n',{format:'NON-PRODUCT arithmetic-only formula control'});
const receipt={generatedAt:new Date().toISOString(),sourceCommitAtStart:manifest.head,sourceCommitAtEnd:execFileSync('git',['rev-parse','HEAD'],{cwd:R,encoding:'utf8'}).trim(),node:process.version,sourceFilesUnchanged:true,source:manifest.source,recordCount:records.length,generated,productionInputMutation:false,limits:['Direct production execution; no browser download.','No calendar import or alerts verified.','Consumer results will be recorded separately.','Time-zone boundary files are generated bytes, not calendar acceptance.']};
await writeFile(join(D,'generation-receipt.json'),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({node:process.version,sourceCommit:manifest.head,recordCount:records.length,fileCount:generated.length,files:generated.map(x=>({name:x.name,bytes:x.bytes,sha256:x.sha256}))}));
