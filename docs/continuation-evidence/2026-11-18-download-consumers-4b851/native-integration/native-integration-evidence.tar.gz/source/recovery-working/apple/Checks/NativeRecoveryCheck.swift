import Foundation
import Darwin

/// Recovery checks for an explicit receipt Stop, distinct unfinished drafts, and profile display labels.
/// This file is intentionally outside the shared check runners and has its own entry point.

@MainActor
private final class TestTokens: ApplicationTokenStore {
    var values: [String: String] = [:]
    func load(account: String) throws -> String? { values[account] }
    func save(_ token: String, account: String) throws { values[account] = token }
    func remove(account: String) throws { values.removeValue(forKey: account) }
}

@MainActor
private final class TestService: MobileApplicationServing {
    struct Call: Equatable { let route: String; let method: String; let body: [String: ApplicationValue]? }
    let origin: URL
    var token: String?
    var calls: [Call] = []
    var handle: (Call) async throws -> [String: ApplicationValue] = { _ in ["ok": .bool(true)] }
    init(_ origin: String = "https://first.example") { self.origin = URL(string: origin)! }
    func request(_ route: String, method: String, body: [String: ApplicationValue]?) async throws -> [String: ApplicationValue] {
        let call = Call(route: route, method: method, body: body); calls.append(call)
        return try await handle(call)
    }
    func invalidate() {}
    func count(_ route: String) -> Int { calls.filter { $0.route == route }.count }
}

@MainActor
private final class DelayedResponse {
    var started = false
    var continuation: CheckedContinuation<[String: ApplicationValue], Error>?
    func wait() async throws -> [String: ApplicationValue] {
        try await withCheckedThrowingContinuation { continuation = $0; started = true }
    }
    func finish(_ value: [String: ApplicationValue]) { continuation?.resume(returning: value); continuation = nil }
    func fail(_ error: Error) { continuation?.resume(throwing: error); continuation = nil }
}

@MainActor
private final class RecoverySuite {
    var checks = 0
    var scenarios = 0
    var folders: [URL] = []
    let success = "Stop requested. Jobs already dispatched still need a confirmed outcome."
    let unsupported = "The destination changed or the backup is not supported. Nothing was imported."
    let draftLimit = "This phone already keeps 200 unfinished edits. Existing drafts were kept."
    let shortlistLimit = "The merged shortlist exceeds 200 links. Nothing was replaced."
    let duplicateLinks = "The backup contains duplicate saved links."
    let recoveredEdit = "Recovered edit selected. Open its record to review and save; earlier draft versions are kept."
    let keptOpportunity = "Unfinished opportunity kept on this phone."
    let staleOpportunity = "This unfinished opportunity changed. Reopen the draft list."
    let abandonedPlan = "abandoned-plan"
    let abandonedAttempt = "attempt-abandoned"
    let livePlan = "live-plan"
    let liveAttempt = "attempt-live"

    func check(_ condition: Bool, _ message: String) throws {
        guard condition else { throw MobileApplicationError(message: "FAILED: " + message) }
        checks += 1
    }
    func waitUntil(_ condition: () -> Bool) async throws {
        for _ in 0..<2000 {
            if condition() { return }
            try await Task.sleep(nanoseconds: 1_000_000)
        }
        throw MobileApplicationError(message: "Timed out waiting for a deterministic fixture")
    }
    func server(_ revision: Int, name: String = "Example") -> [String: ApplicationValue] {
        var value = PhoneApplicationProfile(); value.firstName = name; value.email = "example@example.invalid"
        var object = value.payload(); object["revision"] = .number(Double(revision)); object["resume"] = .null
        return object
    }
    func workspace(_ revision: Int, attempts: [[String: ApplicationValue]] = [], plans: [[String: ApplicationValue]] = [],
                   active: [String] = [], continuation: String? = nil) -> [String: ApplicationValue] {
        var value: [String: ApplicationValue] = [
            "ok": .bool(true), "workspaceId": .string("workspace-a"), "profile": .object(server(revision)),
            "jobs": .array([]), "attempts": .array(attempts.map(ApplicationValue.object)),
            "recoverablePlans": .array(plans.map(ApplicationValue.object)),
            "activePlanIds": .array(active.map(ApplicationValue.string)), "mode": .string("test")]
        if let continuation { value["capabilities"] = .object(["dispatchContinuation": .string(continuation)]) }
        return value
    }
    func review(_ id: String) -> [String: ApplicationValue] {
        ["id": .string(id), "digest": .string("digest-" + id), "profileRevision": .number(3),
         "expiresAt": .string(ISO8601DateFormatter().string(from: Date().addingTimeInterval(3600))),
         "stopped": .bool(false), "approvedAt": .null,
         "items": .array([.object(["jobId": .string("job-1"), "state": .string("ready"),
            "job": .object(["title": .string("Synthetic role"), "company": .string("Fixture")]),
            "payloadSummary": .object(["consentMarketing": .bool(false)])])])]
    }
    func attempt(_ id: String, _ state: String, plan: String) -> [String: ApplicationValue] {
        ["id": .string(id), "attemptId": .string(id), "state": .string(state), "planId": .string(plan)]
    }
    func initial(_ revision: Int = 3) throws -> PhoneApplicationState {
        var state = PhoneApplicationState(); state.acknowledge(try ApplicationServerProfile(server(revision)))
        state.serviceAddress = "https://first.example"; state.workspaceID = "workspace-a"
        state.connectionEnabled = true; state.credentialAccount = "fixture-account"
        return state
    }
    func scope() -> PhoneRecordScope { PhoneRecordScope(origin: "https://first.example", workspaceID: "workspace-a") }
    func jobMap(_ name: String, noteTitle: String = "Role") -> [String: ApplicationValue] {
        ["url": .string("https://jobs.example.com/" + name), "title": .string(noteTitle), "company": .string("Fixture Co"),
         "location": .string("Riyadh"), "country": .string("SA")]
    }
    func checkpoint(_ name: String, note: String, revision: Int? = nil, stage: PhoneApplicationStage = .saved, recordID: String? = nil) -> PhoneRecordDraftCheckpoint {
        let job = PhoneRecordJob(jobMap(name, noteTitle: note))
        var draft = PhoneRecordDraft(); draft.note = note; draft.stage = stage
        return PhoneRecordDraftCheckpoint(scope: scope(), identity: job.identity, job: job, recordID: recordID, revision: revision, draft: draft)
    }
    func opportunity(_ title: String, url: String) -> PhoneOpportunityDraft {
        PhoneOpportunityDraft(url: url, title: title, company: "Fixture Co", location: "Riyadh", country: "SA")
    }
    func opportunityBackup(current: PhoneOpportunityDraft = PhoneOpportunityDraft(), recovered: [PhoneOpportunityDraft] = []) -> PhoneWorkspaceBackup {
        var value = backup([])
        value.draft.opportunityDraft = current
        value.recoveredOpportunityDrafts = recovered
        return value
    }
    func backup(_ drafts: [PhoneRecordDraftCheckpoint], jobs: [[String: ApplicationValue]] = [], schema: Int = 1) -> PhoneWorkspaceBackup {
        let draft = PhoneWorkspaceDraft(scope: scope(), profile: PhoneApplicationProfile(), profileNeedsSync: false,
            profileRevision: nil, latestServerRevision: nil, latestServerProfile: nil, jobs: jobs, opportunityDraft: PhoneOpportunityDraft())
        var value = PhoneWorkspaceBackup(draft: draft, records: [], recordDrafts: drafts, submissionHolds: [])
        value.schemaVersion = schema
        return value
    }
    func fixture(_ state: PhoneApplicationState, service: TestService) throws -> (NativeApplicationsStore, URL, TestTokens) {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("career-recovery-" + UUID().uuidString)
        folders.append(folder); try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        try JSONEncoder().encode(state).write(to: folder.appendingPathComponent("phone-draft.json"))
        let tokens = TestTokens(); tokens.values[state.tokenAccount] = "synthetic-token"
        let store = NativeApplicationsStore(folder: folder, credentials: tokens, clientFactory: { _, token in service.token = token; return service })
        return (store, folder, tokens)
    }
    func savedState(_ folder: URL) throws -> PhoneApplicationState {
        try JSONDecoder().decode(PhoneApplicationState.self, from: Data(contentsOf: folder.appendingPathComponent("phone-draft.json")))
    }
    func cleanup() { for folder in folders { try? FileManager.default.removeItem(at: folder) } }

    func profileLabels() throws {
        try check(PhoneProfileDisplay.experienceLabel(for: "entry") == "Entry level", "entry displays as Entry level")
        try check(PhoneProfileDisplay.experienceLabel(for: "mid") == "Mid level", "mid displays as Mid level")
        try check(PhoneProfileDisplay.experienceLabel(for: "Entry level") == "Entry level" && PhoneProfileDisplay.experienceLabel(for: "Mid level") == "Mid level",
                  "English human-readable labels map to themselves")
        try check(PhoneProfileDisplay.experienceLabel(for: "Entry") == nil && PhoneProfileDisplay.experienceLabel(for: "ملاحظة خاصة") == nil,
                  "Short chip words and arbitrary text stay unmapped on iPhone")
        try check(PhoneProfileDisplay.workPreferenceLabels(remote: true, hybrid: true, onsite: false) == ["Remote", "Hybrid"],
                  "Work-mode labels stay Remote then Hybrid")
        var state = try initial()
        state.profile.experienceLevel = "entry"; state.profile.remote = true; state.profile.hybrid = true; state.profile.onsite = false
        state.profile.firstName = "أحمد"; state.profileNeedsSync = true; state.profileRevision = 3; state.latestServerRevision = 4
        var serverProfile = PhoneApplicationProfile()
        serverProfile.firstName = "Server"; serverProfile.experienceLevel = "mid"
        serverProfile.remote = false; serverProfile.hybrid = false; serverProfile.onsite = true
        state.latestServerProfile = serverProfile
        let service = TestService()
        let (store, folder, _) = try fixture(state, service: service)
        let draft = store.profile
        try check(store.editContext.revision == 3, "The keep action starts from the stored draft revision")
        try check(store.keepDraftAfterReview(draft, context: store.editContext, serverRevision: 4), "Keeping the phone version succeeds")
        try check(store.profile.experienceLevel == "entry" && store.profile.firstName == "أحمد"
                  && store.profile.remote && store.profile.hybrid && !store.profile.onsite,
                  "Keep version preserves the stored wire value, Arabic name and work-mode booleans")
        try check(store.profile.experienceLevel != "Entry level" && store.profile.experienceLevel != "مبتدئ",
                  "The persisted experience value is not a display label")
        try check(store.useLatestProfile(context: store.editContext), "Using the latest service profile succeeds")
        try check(store.profile.experienceLevel == "mid" && store.profile.firstName == "Server"
                  && !store.profile.remote && !store.profile.hybrid && store.profile.onsite,
                  "Use latest stores the service wire value and booleans")
        let saved = try savedState(folder)
        try check(saved.profile.experienceLevel == "mid" && saved.profile.firstName == "Server" && service.calls.isEmpty,
                  "The chosen profile is what restart would read, and neither choice contacted the service")
        scenarios += 1
    }

    func receipts() async throws {
        let dispatching = workspace(3, attempts: [attempt(abandonedAttempt, "dispatching", plan: abandonedPlan)])
        let service = TestService()
        service.handle = { _ in dispatching }
        let (store, _, _) = try fixture(try initial(), service: service)
        try check(await store.refresh(), "A workspace refresh reads the dispatching receipt")
        try check(store.activePlanIDs.isEmpty && store.recoverablePlans.isEmpty, "An expired dispatch is absent from active and recoverable plans")
        try check(service.count("stop") == 0 && service.count("submit") == 0 && service.count("advance") == 0,
                  "Refresh does not stop, submit or advance")
        let long = String(repeating: "p", count: 201)
        await store.stopAndCheckReceipt(planID: long, attemptID: abandonedAttempt)
        await store.stopAndCheckReceipt(planID: abandonedPlan, attemptID: long)
        try check(service.count("stop") == 0, "Over-long receipt ids send no Stop")

        service.handle = { call in
            if call.route == "stop" { return ["ok": .bool(true)] }
            return dispatching
        }
        await store.stopAndCheckReceipt(planID: abandonedPlan, attemptID: abandonedAttempt)
        try check(service.count("stop") == 1 && service.count("submit") == 0 && service.count("advance") == 0, "One explicit Stop and no submit or advance")
        let stop = service.calls.first { $0.route == "stop" }
        try check(stop?.method == "POST" && stop?.body == ["planId": .string(self.abandonedPlan), "onlyIfUnapproved": .bool(false)],
                  "The receipt Stop sends planId and onlyIfUnapproved false")
        try check(store.attempts.first?["state"]?.string == "dispatching" && store.message == success,
                  "The receipt stays dispatching when the following read still says dispatching")
        scenarios += 1

        let gate = DelayedResponse()
        var reads = 0
        let uncertain = TestService()
        uncertain.handle = { call in
            if call.route == "stop" { return ["ok": .bool(true)] }
            reads += 1
            if reads == 1 { return dispatching }
            return try await gate.wait()
        }
        let (uncertainStore, _, _) = try fixture(try initial(), service: uncertain)
        try check(await uncertainStore.refresh(), "The uncertain fixture loads the dispatching receipt first")
        let stopping = Task { await uncertainStore.stopAndCheckReceipt(planID: self.abandonedPlan, attemptID: self.abandonedAttempt) }
        try await waitUntil { gate.started }
        try check(uncertainStore.attempts.first?["state"]?.string == "dispatching", "Stop does not locally invent uncertain before the workspace read returns")
        gate.finish(workspace(3, attempts: [attempt(abandonedAttempt, "uncertain", plan: abandonedPlan)]))
        await stopping.value
        try check(uncertainStore.attempts.first?["state"]?.string == "uncertain", "Uncertain appears only when the following workspace read says uncertain")
        scenarios += 1

        let liveService = TestService()
        let liveSnapshot = workspace(3, attempts: [attempt(abandonedAttempt, "dispatching", plan: abandonedPlan), attempt(liveAttempt, "dispatching", plan: livePlan)],
                                      plans: [review(livePlan)], active: [livePlan])
        liveService.handle = { call in
            if call.route == "stop" { return ["ok": .bool(true)] }
            return liveSnapshot
        }
        let (liveStore, _, _) = try fixture(try initial(), service: liveService)
        try check(await liveStore.refresh(), "The live-lease fixture loads both receipts")
        await liveStore.stopAndCheckReceipt(planID: abandonedPlan, attemptID: abandonedAttempt)
        try check(liveService.calls.first { $0.route == "stop" }?.body?["planId"]?.string == abandonedPlan, "Stop targets the receipt plan, not the live plan")
        try check(liveStore.activePlanIDs == [livePlan], "The live lease remains active")
        try check(liveStore.attempts.contains { ($0["attemptId"]?.string ?? "") == self.liveAttempt && $0["state"]?.string == "dispatching" },
                  "The live receipt stays dispatching")
        scenarios += 1

        var lateReads = 0
        let late = TestService()
        late.handle = { call in
            if call.route == "stop" { return ["ok": .bool(true)] }
            lateReads += 1
            if lateReads == 1 { return dispatching }
            return self.workspace(3, attempts: [self.attempt(self.abandonedAttempt, "submitted", plan: self.abandonedPlan)])
        }
        let (lateStore, _, _) = try fixture(try initial(), service: late)
        try check(await lateStore.refresh(), "The late-result fixture loads the dispatching receipt")
        await lateStore.stopAndCheckReceipt(planID: abandonedPlan, attemptID: abandonedAttempt)
        try check(lateStore.attempts.first?["state"]?.string == "submitted", "A later real submitted result replaces the dispatching snapshot")
        scenarios += 1

        var failedReads = 0
        let failing = TestService()
        failing.handle = { call in
            if call.route == "stop" { return ["ok": .bool(true)] }
            failedReads += 1
            if failedReads == 1 { return dispatching }
            throw URLError(.notConnectedToInternet)
        }
        let (failedStore, _, _) = try fixture(try initial(), service: failing)
        try check(await failedStore.refresh(), "The failed-read fixture loads the dispatching receipt")
        await failedStore.stopAndCheckReceipt(planID: abandonedPlan, attemptID: abandonedAttempt)
        try check(failedStore.attempts.first?["state"]?.string == "dispatching" && failedStore.message != success,
                  "A workspace read that fails after Stop leaves the last dispatching snapshot and does not keep the success sentence")
        scenarios += 1

        let lost = TestService()
        lost.handle = { call in
            if call.route == "stop" { throw URLError(.notConnectedToInternet) }
            return dispatching
        }
        let (lostStore, folder, tokens) = try fixture(try initial(), service: lost)
        try check(await lostStore.refresh(), "The lost-response fixture loads the dispatching receipt")
        let readsBefore = lost.count("workspace")
        await lostStore.stopAndCheckReceipt(planID: abandonedPlan, attemptID: abandonedAttempt)
        try check(lost.count("stop") == 1 && lost.count("workspace") == readsBefore && lost.count("advance") == 0,
                  "A lost Stop response records the request and does not refresh or advance")
        try check(lostStore.attempts.first?["state"]?.string == "dispatching", "The receipt stays dispatching when Stop's response is lost")
        try check(try savedState(folder).submissionHolds.contains { $0.planID == self.abandonedPlan }, "The Stop hold is on disk before any retry")
        let resumed = TestService()
        resumed.handle = { call in
            if call.route == "advance" { return ["ok": .bool(true)] }
            return self.workspace(3, attempts: [self.attempt(self.abandonedAttempt, "dispatching", plan: self.abandonedPlan)],
                                   plans: [self.review(self.abandonedPlan)], active: [self.abandonedPlan], continuation: "client")
        }
        let reopened = NativeApplicationsStore(folder: folder, credentials: tokens, clientFactory: { _, token in resumed.token = token; return resumed })
        await reopened.pollApprovedApplications()
        try check(resumed.count("advance") == 0 && reopened.heldPlanIDs.contains(abandonedPlan),
                  "After restart the held plan is not advanced")
        scenarios += 1

        let race = TestService()
        let (raceStore, _, _) = try fixture(try initial(), service: race)
        race.handle = { call in
            if call.route == "stop" {
                await raceStore.disconnect()
                return ["ok": .bool(true)]
            }
            if call.route == "session/revoke" { return ["ok": .bool(true)] }
            return dispatching
        }
        try check(await raceStore.refresh(), "The account-race fixture loads the dispatching receipt")
        let workspaceReads = race.count("workspace")
        await raceStore.stopAndCheckReceipt(planID: abandonedPlan, attemptID: abandonedAttempt)
        try await waitUntil { race.calls.contains { $0.route == "session/revoke" } }
        try check(raceStore.message != success && race.count("stop") == 1 && race.count("workspace") == workspaceReads,
                  "Disconnect during Stop drops the success sentence and sends no later workspace read")
        await raceStore.stopAndCheckReceipt(planID: abandonedPlan, attemptID: abandonedAttempt)
        try check(race.count("stop") == 1, "A disconnected phone does not send Stop to another workspace")
        scenarios += 1

        let busyService = TestService()
        let busyGate = DelayedResponse()
        busyService.handle = { call in
            if call.route == "session" { return try await busyGate.wait() }
            return dispatching
        }
        let (busyStore, busyFolder, _) = try fixture(try initial(), service: busyService)
        try check(await busyStore.refresh(), "The busy fixture loads the dispatching receipt")
        let connecting = Task { await busyStore.connect(address: "https://first.example", code: "fixture-code") }
        try await waitUntil { busyGate.started && busyStore.busy }
        await busyStore.stopAndCheckReceipt(planID: abandonedPlan, attemptID: abandonedAttempt)
        try check(busyService.count("stop") == 0, "Stop during an in-flight connection sends no request")
        try check(try savedState(busyFolder).submissionHolds.contains { $0.planID == self.abandonedPlan }, "The busy Stop still saves the hold")
        busyGate.fail(URLError(.cancelled))
        _ = await connecting.value
        try check(!busyStore.busy, "The connection attempt finishes after its fixture is released")
        scenarios += 1
    }

    func drafts() throws {
        let service = TestService()
        let (store, folder, tokens) = try fixture(try initial(), service: service)
        let applied = checkpoint("role", note: "نسخة مطبقة {ليست إيصالاً}", revision: 1, stage: .applied)
        let other = checkpoint("role", note: "نسخة ثانية {أقواس} و \\u007b داخل النص", revision: 2)
        let jobs = [jobMap("role")]
        try check(store.mergeBackup(backup([applied, other], jobs: jobs), context: store.workspaceActionContext), "An empty phone accepts two distinct drafts for one job")
        try check(store.unfinishedRecordDrafts.count == 1 && store.recoveredRecordDrafts.count == 1, "One draft stays current and the other is kept as an alternative")
        try check(store.unfinishedRecordDrafts[0].draft.note == applied.draft.note && store.recoveredRecordDrafts[0].draft.note == other.draft.note,
                  "Import order keeps the first distinct draft current")
        try check(try savedState(folder).applicationRecords.isEmpty, "An applied-stage draft does not become an application record")
        let exported = store.exportWorkspace(context: store.workspaceActionContext)
        let exportedBackup = try NativeApplicationsStore.readWorkspaceBackup(at: exported!)
        try check(exportedBackup.recordDrafts.map(\.draft.note) == [applied.draft.note, other.draft.note],
                  "Re-export writes the current draft before its alternative, including Arabic text and braces")
        let reopened = NativeApplicationsStore(folder: folder, credentials: tokens, clientFactory: { _, token in service.token = token; return service })
        try check(reopened.unfinishedRecordDrafts.map(\.draft.note) == [applied.draft.note]
                  && reopened.recoveredRecordDrafts.map(\.draft.note) == [other.draft.note],
                  "Restart keeps both unfinished drafts and their notes")
        let alternative = reopened.recoveredRecordDrafts[0]
        try check(reopened.useRecoveredRecordDraft(alternative) && reopened.message == recoveredEdit, "Selecting a recovered edit reports that earlier versions stay")
        try check(reopened.unfinishedRecordDrafts.map(\.draft.note) == [other.draft.note]
                  && reopened.recoveredRecordDrafts.map(\.draft.note) == [applied.draft.note],
                  "Selection swaps the current draft and keeps the earlier one")
        let job = reopened.savedOpportunities.first { MobileApplicationPolicy.jobIdentity($0["url"]?.string ?? "") == applied.identity }
        let edit = job.flatMap { reopened.recordEditContext(for: $0) }
        var saving = PhoneRecordDraft(); saving.stage = .saved; saving.note = "حفظ متعمد"
        try check(edit != nil && reopened.saveRecord(saving, context: edit!), "A deliberate save of the selected draft succeeds")
        let saved = try savedState(folder)
        try check(saved.applicationRecords.count == 1 && saved.applicationRecords[0].stage == .saved
                  && saved.applicationRecords[0].appliedElsewhere == false && saved.applicationRecords[0].note == "حفظ متعمد",
                  "Saving stage saved does not mark the job applied or invent provider evidence")
        scenarios += 1

        var existing = try initial()
        let current = checkpoint("role", note: "المسودة الحالية", revision: 1)
        existing.recordDrafts = [current]
        let (existingStore, existingFolder, _) = try fixture(existing, service: TestService())
        let incomingA = checkpoint("role", note: "بديل أول", revision: 2)
        let incomingB = checkpoint("role", note: "بديل ثان", revision: 3)
        try check(existingStore.mergeBackup(backup([incomingA, incomingB], jobs: jobs), context: existingStore.workspaceActionContext),
                  "An existing destination accepts distinct incoming drafts")
        try check(existingStore.unfinishedRecordDrafts.map(\.draft.note) == ["المسودة الحالية"], "The destination's current draft stays current")
        try check(Set(existingStore.recoveredRecordDrafts.map(\.draft.note)) == Set(["بديل أول", "بديل ثان"]),
                  "Two distinct incoming drafts become alternatives")
        try check(try savedState(existingFolder).applicationRecords.isEmpty, "Incoming alternatives do not create application records")
        scenarios += 1

        let (sameStore, _, _) = try fixture(try initial(), service: TestService())
        let left = checkpoint("role", note: "نفس النص", revision: 4, recordID: UUID().uuidString)
        var right = left; right.recordID = UUID().uuidString
        try check(sameStore.mergeBackup(backup([left, right]), context: sameStore.workspaceActionContext), "Identical draft content can be offered twice")
        try check(sameStore.unfinishedRecordDrafts.count == 1 && sameStore.recoveredRecordDrafts.isEmpty,
                  "The same identity, draft and revision is not stored twice")
        let changed = checkpoint("role", note: "نفس النص", revision: 5)
        try check(sameStore.mergeBackup(backup([changed]), context: sameStore.workspaceActionContext), "A different revision is a distinct unfinished edit")
        try check(sameStore.unfinishedRecordDrafts.count == 1 && sameStore.recoveredRecordDrafts.count == 1
                  && sameStore.recoveredRecordDrafts[0].revision == 5, "A different revision is kept as an alternative")
        scenarios += 1

        var old = try initial()
        old.recordDrafts = [checkpoint("legacy", note: "old backup")]
        var text = String(data: try JSONEncoder().encode(old), encoding: .utf8)!
        try check(text.contains("\"recordDraftAlternatives\":[]"), "A current phone draft encodes an empty alternatives list")
        text = text.replacingOccurrences(of: "\"recordDraftAlternatives\":[],", with: "")
        let decoded = try JSONDecoder().decode(PhoneApplicationState.self, from: Data(text.utf8))
        try check(decoded.recordDraftAlternatives.isEmpty && decoded.recordDrafts.count == 1 && decoded.recordDrafts[0].draft.note == "old backup",
                  "A phone draft written before alternatives existed decodes with the current draft intact")
        scenarios += 1

        let (damagedStore, damagedFolder, _) = try fixture(try initial(), service: TestService())
        let before = try Data(contentsOf: damagedFolder.appendingPathComponent("phone-draft.json"))
        var damaged = backup([checkpoint("damaged", note: "do not import")])
        damaged.schemaVersion = 99
        let source = damagedFolder.appendingPathComponent("source-backup.json")
        let sourceBytes = try JSONEncoder().encode(damaged)
        try sourceBytes.write(to: source)
        try check(!damagedStore.mergeBackup(damaged, context: damagedStore.workspaceActionContext) && damagedStore.message == unsupported,
                  "Backup schema 99 uses the generic unsupported message")
        try check(try Data(contentsOf: damagedFolder.appendingPathComponent("phone-draft.json")) == before, "A rejected backup leaves the phone draft unchanged")
        do {
            _ = try NativeApplicationsStore.readWorkspaceBackup(at: source)
            try check(false, "A schema 99 file is not accepted as a backup")
        } catch {
            try check(error.localizedDescription.contains("unchanged"), "Reading a damaged backup reports that existing files stay unchanged")
        }
        try check(try Data(contentsOf: source) == sourceBytes, "Reading or rejecting a backup does not modify the source file")
        scenarios += 1

        let tooMany = (0..<201).map { checkpoint("bulk-\($0)", note: "draft \($0)") }
        let (limitStore, limitFolder, _) = try fixture(try initial(), service: TestService())
        let limitBefore = try Data(contentsOf: limitFolder.appendingPathComponent("phone-draft.json"))
        try check(!limitStore.mergeBackup(backup(tooMany), context: limitStore.workspaceActionContext) && limitStore.message == unsupported,
                  "A backup that itself contains 201 drafts is rejected as unsupported")
        try check(try Data(contentsOf: limitFolder.appendingPathComponent("phone-draft.json")) == limitBefore, "An oversized backup does not change the phone")
        scenarios += 1

        var full = try initial()
        full.recordDrafts = (0..<200).map { checkpoint("full-\($0)", note: "kept \($0)") }
        let (fullStore, fullFolder, _) = try fixture(full, service: TestService())
        let fullBefore = try Data(contentsOf: fullFolder.appendingPathComponent("phone-draft.json"))
        try check(!fullStore.mergeBackup(backup([checkpoint("one-more", note: "one more")]), context: fullStore.workspaceActionContext)
                  && fullStore.message == draftLimit, "A phone that already keeps 200 drafts rejects one more with the draft-limit message")
        try check(fullStore.unfinishedRecordDrafts.count == 200 && fullStore.recoveredRecordDrafts.isEmpty, "The existing 200 drafts stay in place")
        try check(try Data(contentsOf: fullFolder.appendingPathComponent("phone-draft.json")) == fullBefore, "The rejected extra draft is not written")
        scenarios += 1

        let (staleStore, staleFolder, _) = try fixture(try initial(), service: TestService())
        try check(staleStore.mergeBackup(backup([checkpoint("stale", note: "base")], jobs: [jobMap("stale")]), context: staleStore.workspaceActionContext),
                  "The stale-context fixture imports one draft and its job")
        let context = staleStore.workspaceActionContext
        let staleJob = staleStore.savedOpportunities.first { ($0["url"]?.string ?? "").contains("/stale") }
        let staleEdit = staleJob.flatMap { staleStore.recordEditContext(for: $0) }
        var localEdit = PhoneRecordDraft(); localEdit.note = "تعديل محلي"
        try check(staleEdit != nil && staleStore.keepRecordDraft(localEdit, context: staleEdit!), "A local edit changes the workspace after the captured context")
        let staleBefore = try Data(contentsOf: staleFolder.appendingPathComponent("phone-draft.json"))
        try check(!staleStore.mergeBackup(backup([checkpoint("other", note: "should not land")]), context: context) && staleStore.message == unsupported,
                  "A stale workspace context cannot import into the changed phone")
        try check(try Data(contentsOf: staleFolder.appendingPathComponent("phone-draft.json")) == staleBefore, "The failed import leaves the edited phone draft unchanged")
        scenarios += 1
    }

    func localJob(_ name: String) -> [String: ApplicationValue] {
        var job = jobMap(name)
        job["id"] = .string("local-" + name)
        job["localOnly"] = .bool(true)
        return job
    }

    func shortlistCap() async throws {
        var full = try initial()
        full.jobs = (0..<200).map { localJob("kept-\($0)") }
        let service = TestService()
        let (store, folder, _) = try fixture(full, service: service)
        let before = try Data(contentsOf: folder.appendingPathComponent("phone-draft.json"))
        let added = await store.addJob(url: "https://jobs.example.com/one-more", title: "One more", company: "Fixture Co", location: "Riyadh", country: "SA")
        try check(!added && store.message == shortlistLimit, "The 201st saved link is refused with the shortlist sentence")
        try check(try Data(contentsOf: folder.appendingPathComponent("phone-draft.json")) == before, "Refusing the 201st link does not write the phone draft")
        try check(service.count("jobs") == 0 && service.count("submit") == 0 && service.count("advance") == 0, "A refused link is not sent")
        let duplicate = await store.addJob(url: "https://jobs.example.com/kept-0", title: "Role", company: "Fixture Co", location: "Riyadh", country: "SA")
        let afterDuplicate = try Data(contentsOf: folder.appendingPathComponent("phone-draft.json"))
        try check(!duplicate && store.message == "This opportunity is already in your workspace.", "A duplicate of a full shortlist still uses the existing notice")
        try check(afterDuplicate == before && service.count("jobs") == 0, "The duplicate notice does not write or send")
        scenarios += 1

        var almost = try initial()
        almost.jobs = (0..<199).map { localJob("open-\($0)") }
        let openService = TestService()
        openService.handle = { call in
            if call.route == "jobs" {
                return ["ok": .bool(true), "job": .object(["id": .string("server-last"), "url": .string("https://jobs.example.com/last"),
                    "title": .string("Last"), "company": .string("Fixture Co")])]
            }
            return self.workspace(3)
        }
        let (openStore, openFolder, _) = try fixture(almost, service: openService)
        let opened = await openStore.addJob(url: "https://jobs.example.com/last", title: "Last", company: "Fixture Co", location: "Riyadh", country: "SA")
        let openedDraft = try savedState(openFolder)
        try check(opened && openedDraft.jobs.count == 200, "The 200th saved link is kept")
        try check(openedDraft.jobs.contains { $0["url"]?.string == "https://jobs.example.com/last" }, "The accepted link is the one the phone saved")
        scenarios += 1

        let remoteJobs = (0..<200).map { index -> [String: ApplicationValue] in
            ["id": .string("server-\(index)"), "url": .string("https://jobs.example.com/server-\(index)"),
             "title": .string("Server"), "company": .string("Fixture Co")]
        }
        var remoteWorkspace = workspace(3)
        remoteWorkspace["jobs"] = .array(remoteJobs.map(ApplicationValue.object))
        let remoteService = TestService()
        remoteService.handle = { call in
            if call.route == "jobs" {
                return ["ok": .bool(true), "job": .object(["id": .string("server-extra"), "url": .string("https://jobs.example.com/phone-only"),
                    "title": .string("Phone"), "company": .string("Fixture Co")])]
            }
            return remoteWorkspace
        }
        let (remoteStore, remoteFolder, _) = try fixture(try initial(), service: remoteService)
        try check(await remoteStore.refresh(), "A full service shortlist loads for display")
        let remoteDraft = try savedState(remoteFolder)
        try check(remoteStore.jobs.count == 200 && remoteDraft.jobs.isEmpty, "Service jobs stay out of the phone draft")
        let localSaved = await remoteStore.addJob(url: "https://jobs.example.com/phone-only", title: "Phone", company: "Fixture Co", location: "Riyadh", country: "SA")
        let phoneDraft = try savedState(remoteFolder)
        try check(localSaved && phoneDraft.jobs.count == 1, "A full service list does not consume the phone draft budget")
        scenarios += 1

        var overflow = try initial()
        overflow.jobs = (0..<201).map { localJob("overflow-\($0)") }
        let (exportStore, exportFolder, _) = try fixture(overflow, service: TestService())
        let exportBefore = try Data(contentsOf: exportFolder.appendingPathComponent("phone-draft.json"))
        let refused = exportStore.exportWorkspace(context: exportStore.workspaceActionContext)
        let written = try FileManager.default.contentsOfDirectory(at: exportFolder, includingPropertiesForKeys: nil)
            .filter { $0.lastPathComponent.hasPrefix("Career-Finder-Phone-Workspace-") }
        let exportAfter = try Data(contentsOf: exportFolder.appendingPathComponent("phone-draft.json"))
        try check(refused == nil && exportStore.message == shortlistLimit, "Export refuses a shortlist the backup cannot import")
        try check(written.isEmpty && exportAfter == exportBefore, "A refused export writes no file and leaves the phone draft unchanged")
        scenarios += 1

        var exact = try initial()
        exact.jobs = (0..<200).map { localJob("export-\($0)") }
        let (exactStore, _, _) = try fixture(exact, service: TestService())
        try check(exactStore.exportWorkspace(context: exactStore.workspaceActionContext) != nil, "Exactly 200 saved links still export")
        scenarios += 1

        let preservedDrafts = "These workspace drafts need a compatible app version. The original phone data has been preserved."
        var exactDrafts = try initial()
        exactDrafts.recordDrafts = (0..<200).map { checkpoint("export-draft-\($0)", note: "kept \($0)") }
        let (exactDraftStore, _, _) = try fixture(exactDrafts, service: TestService())
        try check(exactDraftStore.exportWorkspace(context: exactDraftStore.workspaceActionContext) != nil, "Exactly 200 unfinished edits still export")
        scenarios += 1

        var overflowDrafts = try initial()
        overflowDrafts.recordDrafts = (0..<201).map { checkpoint("overflow-draft-\($0)", note: "kept \($0)") }
        let (overflowDraftStore, overflowDraftFolder, _) = try fixture(overflowDrafts, service: TestService())
        let overflowDraftBefore = try Data(contentsOf: overflowDraftFolder.appendingPathComponent("phone-draft.json"))
        let overflowDraftRefused = overflowDraftStore.exportWorkspace(context: overflowDraftStore.workspaceActionContext)
        let overflowDraftWritten = try FileManager.default.contentsOfDirectory(at: overflowDraftFolder, includingPropertiesForKeys: nil)
            .filter { $0.lastPathComponent.hasPrefix("Career-Finder-Phone-Workspace-") }
        let overflowDraftAfter = try Data(contentsOf: overflowDraftFolder.appendingPathComponent("phone-draft.json"))
        try check(overflowDraftRefused == nil && overflowDraftStore.message == preservedDrafts
                  && overflowDraftStore.unfinishedRecordDrafts.isEmpty, "A phone file with 201 unfinished edits is kept and not exported")
        try check(overflowDraftWritten.isEmpty && overflowDraftAfter == overflowDraftBefore,
                  "The unread draft file is not replaced and no backup is written")
        scenarios += 1

        var overflowRecovered = try initial()
        overflowRecovered.recoveredOpportunityDrafts = (0..<201).map { index in
            PhoneRecoveredOpportunity(scope: scope(), draft: opportunity("Parked \(index)", url: "https://jobs.example.com/export-parked-\(index)"))
        }
        let (overflowRecoveredStore, overflowRecoveredFolder, _) = try fixture(overflowRecovered, service: TestService())
        let overflowRecoveredBefore = try Data(contentsOf: overflowRecoveredFolder.appendingPathComponent("phone-draft.json"))
        let overflowRecoveredRefused = overflowRecoveredStore.exportWorkspace(context: overflowRecoveredStore.workspaceActionContext)
        let overflowRecoveredWritten = try FileManager.default.contentsOfDirectory(at: overflowRecoveredFolder, includingPropertiesForKeys: nil)
            .filter { $0.lastPathComponent.hasPrefix("Career-Finder-Phone-Workspace-") }
        let overflowRecoveredAfter = try Data(contentsOf: overflowRecoveredFolder.appendingPathComponent("phone-draft.json"))
        try check(overflowRecoveredRefused == nil && overflowRecoveredStore.message == preservedDrafts
                  && overflowRecoveredStore.recoveredOpportunityDrafts.isEmpty, "A phone file with 201 parked opportunities is kept and not exported")
        try check(overflowRecoveredWritten.isEmpty && overflowRecoveredAfter == overflowRecoveredBefore,
                  "The unread parked-opportunity file is not replaced and no backup is written")
        scenarios += 1

        var paired = try initial()
        let first = localJob("paired")
        var second = localJob("paired-copy")
        second["url"] = first["url"] ?? .string("")
        second["title"] = .string("Different title")
        paired.jobs = [first, second]
        let (pairStore, pairFolder, _) = try fixture(paired, service: TestService())
        let pairBefore = try Data(contentsOf: pairFolder.appendingPathComponent("phone-draft.json"))
        let pairRefused = pairStore.exportWorkspace(context: pairStore.workspaceActionContext)
        let pairWritten = try FileManager.default.contentsOfDirectory(at: pairFolder, includingPropertiesForKeys: nil)
            .filter { $0.lastPathComponent.hasPrefix("Career-Finder-Phone-Workspace-") }
        let pairAfter = try Data(contentsOf: pairFolder.appendingPathComponent("phone-draft.json"))
        try check(pairRefused == nil && pairStore.message == duplicateLinks, "Export refuses two saved links with the same address")
        try check(pairWritten.isEmpty && pairAfter == pairBefore, "A duplicate-link export writes no file and leaves the phone draft unchanged")
        try check(pairStore.jobs.count == 2, "Refusing the export keeps both saved links")
        scenarios += 1

        var tracked = try initial()
        let plain = localJob("tracked")
        var tagged = localJob("tracked-utm")
        tagged["url"] = .string("https://jobs.example.com/tracked?utm_source=phone")
        tagged["title"] = .string("Tracked title")
        tracked.jobs = [plain, tagged]
        let (trackStore, trackFolder, _) = try fixture(tracked, service: TestService())
        let trackBefore = try Data(contentsOf: trackFolder.appendingPathComponent("phone-draft.json"))
        let trackRefused = trackStore.exportWorkspace(context: trackStore.workspaceActionContext)
        let trackWritten = try FileManager.default.contentsOfDirectory(at: trackFolder, includingPropertiesForKeys: nil)
            .filter { $0.lastPathComponent.hasPrefix("Career-Finder-Phone-Workspace-") }
        let trackAfter = try Data(contentsOf: trackFolder.appendingPathComponent("phone-draft.json"))
        try check(trackRefused == nil && trackStore.message == duplicateLinks, "Export refuses a tracking-parameter copy of a saved link")
        try check(trackWritten.isEmpty && trackAfter == trackBefore, "The tracking-parameter refusal writes nothing and leaves both rows")
        scenarios += 1

        let (sameStore, sameFolder, _) = try fixture(try initial(), service: TestService())
        let sameBefore = try Data(contentsOf: sameFolder.appendingPathComponent("phone-draft.json"))
        var sameCopy = localJob("incoming-copy")
        sameCopy["url"] = localJob("incoming")["url"] ?? .string("")
        sameCopy["title"] = .string("Second title")
        try check(!sameStore.mergeBackup(backup([], jobs: [localJob("incoming"), sameCopy]), context: sameStore.workspaceActionContext)
                  && sameStore.message == duplicateLinks, "Import refuses a backup whose own saved links repeat")
        try check(try Data(contentsOf: sameFolder.appendingPathComponent("phone-draft.json")) == sameBefore, "The refused duplicate backup does not change the phone")
        scenarios += 1

        let (utmStore, utmFolder, _) = try fixture(try initial(), service: TestService())
        let utmBefore = try Data(contentsOf: utmFolder.appendingPathComponent("phone-draft.json"))
        var utmCopy = localJob("incoming-utm")
        utmCopy["url"] = .string("https://jobs.example.com/incoming-plain?utm_source=phone")
        utmCopy["title"] = .string("Tracked incoming")
        try check(!utmStore.mergeBackup(backup([], jobs: [localJob("incoming-plain"), utmCopy]), context: utmStore.workspaceActionContext)
                  && utmStore.message == duplicateLinks, "Import refuses a tracking-parameter copy inside one backup")
        try check(try Data(contentsOf: utmFolder.appendingPathComponent("phone-draft.json")) == utmBefore, "The tracking-parameter backup leaves the phone unchanged")
        scenarios += 1

        let (distinctStore, distinctFolder, _) = try fixture(try initial(), service: TestService())
        try check(distinctStore.mergeBackup(backup([], jobs: [localJob("alpha"), localJob("beta")]), context: distinctStore.workspaceActionContext),
                  "Two different saved links in one backup still import")
        let distinctSaved = try savedState(distinctFolder)
        try check(distinctSaved.jobs.count == 2
                  && distinctSaved.jobs.contains { $0["title"]?.string == "Role" && ($0["url"]?.string ?? "").hasSuffix("/alpha") }
                  && distinctSaved.jobs.contains { ($0["url"]?.string ?? "").hasSuffix("/beta") },
                  "Both distinct incoming links are kept")
        scenarios += 1
    }

    func opportunityDrafts() throws {
        let otherScope = PhoneRecordScope(origin: "https://second.example", workspaceID: "workspace-b")
        let adopted = opportunity("Adopted", url: "https://jobs.example.com/adopted")
        let (emptyStore, emptyFolder, _) = try fixture(try initial(), service: TestService())
        try check(emptyStore.mergeBackup(opportunityBackup(current: adopted, recovered: [adopted]), context: emptyStore.workspaceActionContext, replaceProfile: false),
                  "An empty phone adopts the incoming opportunity draft")
        let emptySaved = try savedState(emptyFolder)
        try check(emptyStore.opportunityDraft == adopted && emptyStore.recoveredOpportunityDrafts.isEmpty
                  && emptySaved.opportunityDraft == adopted && emptySaved.recoveredOpportunityDrafts.isEmpty,
                  "Adopting that draft does not also park a copy of it")
        scenarios += 1

        var occupied = try initial()
        let kept = opportunity("Keep me", url: "https://jobs.example.com/keep")
        let already = opportunity("Already parked", url: "https://jobs.example.com/already")
        let parkedIncoming = opportunity("Parked incoming", url: "https://jobs.example.com/parked")
        occupied.opportunityDraft = kept
        occupied.recoveredOpportunityDrafts = [PhoneRecoveredOpportunity(scope: scope(), draft: already)]
        let (occupiedStore, occupiedFolder, _) = try fixture(occupied, service: TestService())
        let occupiedContext = occupiedStore.workspaceActionContext
        try check(occupiedStore.mergeBackup(opportunityBackup(current: parkedIncoming, recovered: [already, parkedIncoming]), context: occupiedContext, replaceProfile: false),
                  "A phone that already has opportunity text keeps it and parks the other draft")
        let occupiedSaved = try savedState(occupiedFolder)
        try check(occupiedStore.opportunityDraft == kept && occupiedStore.recoveredOpportunityDrafts == [already, parkedIncoming],
                  "The parked draft is stored once, after the draft this workspace already kept")
        try check(occupiedSaved.opportunityDraft == kept
                  && occupiedSaved.recoveredOpportunityDrafts.map(\.draft) == [already, parkedIncoming]
                  && occupiedSaved.recoveredOpportunityDrafts.allSatisfy { $0.scope == scope() },
                  "The parked opportunity survives reload and stays bound to this workspace")
        let occupiedAfter = occupiedStore.workspaceActionContext
        try check(occupiedContext.connection == occupiedAfter.connection && occupiedContext.content != occupiedAfter.content,
                  "Parking an opportunity rotates the workspace content token and keeps the connection")
        try check(!occupiedStore.mergeBackup(backup([]), context: occupiedContext, replaceProfile: false)
                  && occupiedStore.message == unsupported,
                  "A context captured before the parked opportunity does not apply again")
        scenarios += 1

        var sameDraft = try initial()
        sameDraft.opportunityDraft = kept
        sameDraft.recoveredOpportunityDrafts = [PhoneRecoveredOpportunity(scope: scope(), draft: already)]
        let (sameDraftStore, sameDraftFolder, _) = try fixture(sameDraft, service: TestService())
        let sameDraftBefore = try Data(contentsOf: sameDraftFolder.appendingPathComponent("phone-draft.json"))
        try check(sameDraftStore.mergeBackup(opportunityBackup(current: kept, recovered: [kept, already]), context: sameDraftStore.workspaceActionContext, replaceProfile: false),
                  "An identical incoming opportunity can be offered again")
        try check(sameDraftStore.opportunityDraft == kept && sameDraftStore.recoveredOpportunityDrafts == [already],
                  "Copies of the current draft and the already parked draft are not stored again")
        try check(try Data(contentsOf: sameDraftFolder.appendingPathComponent("phone-draft.json")) == sameDraftBefore,
                  "An identical opportunity import does not rewrite the phone file")
        scenarios += 1

        let (androidSource, androidFolder, _) = try fixture(occupied, service: TestService())
        let exportedAndroid = androidSource.exportWorkspace(context: androidSource.workspaceActionContext)
        var androidObject = try JSONSerialization.jsonObject(with: Data(contentsOf: exportedAndroid!)) as! [String: Any]
        androidObject["platform"] = "android"
        var androidData = androidObject["data"] as! [String: Any]
        androidData["opportunityDraft"] = ["url": "https://jobs.example.com/android-current", "title": "Android current",
                                            "company": "Fixture Co", "location": "Riyadh", "country": "SA"]
        androidObject["data"] = androidData
        androidObject["extensions"] = ["android": [
            "recoveredOpportunityDrafts": [["url": "https://jobs.example.com/android-parked", "title": "Android parked",
                                            "company": "Fixture Co", "location": "Riyadh", "country": "SA"]],
            "receiptArchive": ["evidenceMode": "imported"]]]
        let androidBackup = try JSONDecoder().decode(PhoneWorkspaceBackup.self, from: try JSONSerialization.data(withJSONObject: androidObject))
        try check(androidBackup.draft.opportunityDraft.title == "Android current"
                  && androidBackup.recoveredOpportunityDrafts.map(\.title) == ["Android parked"]
                  && androidBackup.discoverySnapshot == nil,
                  "An Android backup decodes its current and parked opportunity drafts and ignores receipt archive data")
        let (androidStore, androidSavedFolder, _) = try fixture(occupied, service: TestService())
        try check(androidStore.mergeBackup(androidBackup, context: androidStore.workspaceActionContext, replaceProfile: false),
                  "The Android opportunity backup merges into the occupied phone")
        let androidSaved = try savedState(androidSavedFolder)
        try check(androidStore.opportunityDraft == kept
                  && androidSaved.recoveredOpportunityDrafts.map(\.draft.title) == ["Already parked", "Android parked", "Android current"],
                  "The destination draft stays and the Android drafts are parked after the one already kept")
        _ = androidFolder
        scenarios += 1

        let restored = androidStore.recoveredOpportunityDrafts[1]
        let androidCurrent = opportunity("Android current", url: "https://jobs.example.com/android-current")
        try check(androidStore.restoreRecoveredOpportunityDraft(restored) && androidStore.message == keptOpportunity,
                  "Continuing a parked opportunity reports that it stays on this phone")
        try check(androidStore.opportunityDraft == restored
                  && androidStore.recoveredOpportunityDrafts == [already, androidCurrent, kept],
                  "Continue swaps that draft in and parks the previous current text")
        let (reopenedOpportunity, _, _) = try fixture(try savedState(androidSavedFolder), service: TestService())
        try check(reopenedOpportunity.opportunityDraft == restored && reopenedOpportunity.recoveredOpportunityDrafts == [already, androidCurrent, kept],
                  "Restart keeps the continued opportunity and the draft it replaced")
        scenarios += 1

        let restoredBytes = try Data(contentsOf: androidSavedFolder.appendingPathComponent("phone-draft.json"))
        let ghost = opportunity("Ghost", url: "https://jobs.example.com/ghost")
        try check(!androidStore.restoreRecoveredOpportunityDraft(ghost) && androidStore.message == staleOpportunity,
                  "A draft that is no longer in this workspace's list is refused")
        try check(try Data(contentsOf: androidSavedFolder.appendingPathComponent("phone-draft.json")) == restoredBytes
                  && androidStore.opportunityDraft == restored,
                  "The stale draft leaves the phone file and the current opportunity unchanged")
        scenarios += 1

        let continuedExport = androidStore.exportWorkspace(context: androidStore.workspaceActionContext)
        let continuedBackup = try NativeApplicationsStore.readWorkspaceBackup(at: continuedExport!)
        let continuedText = String(decoding: try Data(contentsOf: continuedExport!), as: UTF8.self)
        try check(continuedText.contains("recoveredOpportunityDrafts")
                  && continuedBackup.recoveredOpportunityDrafts == androidStore.recoveredOpportunityDrafts,
                  "Export writes this workspace's parked opportunity drafts")
        scenarios += 1

        let (plainStore, plainFolder, _) = try fixture(try initial(), service: TestService())
        let plainExport = plainStore.exportWorkspace(context: plainStore.workspaceActionContext)
        let plainRoot = try JSONSerialization.jsonObject(with: Data(contentsOf: plainExport!)) as! [String: Any]
        let plainExtensions = plainRoot["extensions"] as? [String: Any]
        let plainText = String(decoding: try Data(contentsOf: plainExport!), as: UTF8.self)
        try check(plainExtensions?["android"] == nil && !plainText.contains("recoveredOpportunityDrafts"),
                  "A phone with no parked opportunity omits that Android extension")
        _ = plainFolder
        scenarios += 1

        var mixed = try initial()
        let visible = opportunity("Visible parked", url: "https://jobs.example.com/visible")
        let otherDraft = opportunity("Other workspace", url: "https://jobs.example.com/other-workspace")
        mixed.opportunityDraft = kept
        mixed.recoveredOpportunityDrafts = [PhoneRecoveredOpportunity(scope: scope(), draft: visible),
                                            PhoneRecoveredOpportunity(scope: otherScope, draft: otherDraft)]
        let (mixedStore, mixedFolder, _) = try fixture(mixed, service: TestService())
        try check(mixedStore.recoveredOpportunityDrafts == [visible], "This workspace's list hides another workspace's parked opportunity")
        let mixedExport = mixedStore.exportWorkspace(context: mixedStore.workspaceActionContext)
        let mixedBackup = try NativeApplicationsStore.readWorkspaceBackup(at: mixedExport!)
        let mixedText = String(decoding: try Data(contentsOf: mixedExport!), as: UTF8.self)
        try check(mixedBackup.recoveredOpportunityDrafts == [visible] && !mixedText.contains("Other workspace"),
                  "Export contains only this workspace's parked opportunity")
        try check(mixedStore.clearWorkspaceOnPhone(context: mixedStore.workspaceActionContext), "Clearing this workspace succeeds")
        let mixedSaved = try savedState(mixedFolder)
        try check(!mixedSaved.opportunityDraft.hasContent
                  && mixedSaved.recoveredOpportunityDrafts == [PhoneRecoveredOpportunity(scope: otherScope, draft: otherDraft)],
                  "Clear removes only this workspace's parked opportunity and keeps the other workspace's draft")
        scenarios += 1

        var unpaired = try initial()
        let localCurrent = opportunity("Local current", url: "https://jobs.example.com/local-current")
        let localParked = opportunity("Local parked", url: "https://jobs.example.com/local-parked")
        unpaired.workspaceDrafts = [PhoneWorkspaceDraft(scope: PhoneRecordScope(), profile: PhoneApplicationProfile(), profileNeedsSync: false,
            profileRevision: nil, latestServerRevision: nil, latestServerProfile: nil, jobs: [], opportunityDraft: localCurrent)]
        unpaired.recoveredOpportunityDrafts = [PhoneRecoveredOpportunity(scope: PhoneRecordScope(), draft: localParked)]
        let (unpairedStore, unpairedFolder, _) = try fixture(unpaired, service: TestService())
        try check(unpairedStore.importUnpairedDraft(context: unpairedStore.workspaceActionContext), "Copying the unpaired opportunity draft succeeds")
        let unpairedSaved = try savedState(unpairedFolder)
        try check(unpairedStore.opportunityDraft == localCurrent, "The empty destination adopts the unpaired current draft")
        try check(unpairedSaved.recoveredOpportunityDrafts.contains(PhoneRecoveredOpportunity(scope: scope(), draft: localParked))
                  && unpairedSaved.recoveredOpportunityDrafts.contains(PhoneRecoveredOpportunity(scope: PhoneRecordScope(), draft: localParked)),
                  "The copy keeps a destination-scoped parked draft and the original local one")
        try check(unpairedSaved.workspaceDrafts.contains { $0.scope.isLocal && $0.opportunityDraft == localCurrent },
                  "The original unpaired opportunity draft remains on the phone")
        scenarios += 1

        var capped = try initial()
        capped.opportunityDraft = kept
        capped.recoveredOpportunityDrafts = (0..<200).map { index in
            PhoneRecoveredOpportunity(scope: scope(), draft: opportunity("Parked \(index)", url: "https://jobs.example.com/parked-\(index)"))
        }
        let (cappedStore, cappedFolder, _) = try fixture(capped, service: TestService())
        let cappedBefore = try Data(contentsOf: cappedFolder.appendingPathComponent("phone-draft.json"))
        try check(!cappedStore.mergeBackup(opportunityBackup(current: parkedIncoming), context: cappedStore.workspaceActionContext, replaceProfile: false)
                  && cappedStore.message == draftLimit, "Two hundred parked drafts in this workspace refuse one more")
        try check(try Data(contentsOf: cappedFolder.appendingPathComponent("phone-draft.json")) == cappedBefore
                  && cappedStore.recoveredOpportunityDrafts.count == 200 && cappedStore.opportunityDraft == kept,
                  "The refused opportunity leaves the current draft and all two hundred parked drafts")
        scenarios += 1

        var otherFull = try initial()
        otherFull.opportunityDraft = kept
        otherFull.recoveredOpportunityDrafts = (0..<200).map { index in
            PhoneRecoveredOpportunity(scope: otherScope, draft: opportunity("Other \(index)", url: "https://jobs.example.com/other-\(index)"))
        }
        let (otherFullStore, otherFullFolder, _) = try fixture(otherFull, service: TestService())
        let otherFullBefore = try Data(contentsOf: otherFullFolder.appendingPathComponent("phone-draft.json"))
        try check(!otherFullStore.mergeBackup(opportunityBackup(current: parkedIncoming), context: otherFullStore.workspaceActionContext, replaceProfile: false)
                  && otherFullStore.message == draftLimit, "Two hundred parked drafts across workspaces refuse one more")
        let otherFullSaved = try savedState(otherFullFolder)
        try check(try Data(contentsOf: otherFullFolder.appendingPathComponent("phone-draft.json")) == otherFullBefore
                  && otherFullStore.recoveredOpportunityDrafts.isEmpty && otherFullStore.opportunityDraft == kept
                  && otherFullSaved.recoveredOpportunityDrafts.count == 200
                  && otherFullSaved.recoveredOpportunityDrafts.allSatisfy { $0.scope == otherScope },
                  "The cross-workspace refusal writes nothing and keeps every other workspace draft")
        scenarios += 1

        let (invalidStore, invalidFolder, _) = try fixture(try initial(), service: TestService())
        let invalidBefore = try Data(contentsOf: invalidFolder.appendingPathComponent("phone-draft.json"))
        var invalidDraft = opportunity("Too long", url: "https://jobs.example.com/too-long")
        invalidDraft.country = "SAU"
        try check(!invalidStore.mergeBackup(opportunityBackup(recovered: [invalidDraft]), context: invalidStore.workspaceActionContext)
                  && invalidStore.message == unsupported, "A parked draft with an invalid country is refused as an unsupported backup")
        try check(try Data(contentsOf: invalidFolder.appendingPathComponent("phone-draft.json")) == invalidBefore,
                  "The invalid parked draft does not change the phone")
        scenarios += 1

        var isolated = try initial()
        let isolatedCurrent = opportunity("Workspace A draft", url: "https://jobs.example.com/workspace-a")
        let isolatedParked = opportunity("Workspace A parked", url: "https://jobs.example.com/workspace-a-parked")
        isolated.opportunityDraft = isolatedCurrent
        isolated.recoveredOpportunityDrafts = [PhoneRecoveredOpportunity(scope: scope(), draft: isolatedParked)]
        isolated.connect(address: "https://second.example", workspace: "workspace-b", account: "person-b",
                         server: try ApplicationServerProfile(server(0, name: "Person B")))
        try check(isolated.recordScope == otherScope && !isolated.opportunityDraft.hasContent
                  && isolated.recoveredOpportunityDrafts == [PhoneRecoveredOpportunity(scope: scope(), draft: isolatedParked)]
                  && isolated.recoveredOpportunityDrafts.filter { $0.scope == isolated.recordScope }.isEmpty,
                  "Opening a fresh workspace does not retarget or display the other workspace's parked opportunity")
        isolated.connect(address: "https://first.example", workspace: "workspace-a", account: "fixture-account",
                         server: try ApplicationServerProfile(server(3)))
        try check(isolated.opportunityDraft == isolatedCurrent
                  && isolated.recoveredOpportunityDrafts == [PhoneRecoveredOpportunity(scope: scope(), draft: isolatedParked)],
                  "Returning to the first workspace restores its current opportunity and parked draft")
        scenarios += 1
    }

    func run() async throws {
        try profileLabels()
        try await receipts()
        try drafts()
        try await shortlistCap()
        try opportunityDrafts()
    }
}

@main
struct NativeRecoveryCheck {
    @MainActor static func main() async {
        let suite = RecoverySuite(); defer { suite.cleanup() }
        do {
            try await suite.run()
            print("PASS \(suite.checks) native recovery assertions across \(suite.scenarios) scenarios")
        } catch {
            fputs(error.localizedDescription + "\n", stderr)
            exit(1)
        }
    }
}
